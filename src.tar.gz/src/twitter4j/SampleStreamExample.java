/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package twitter4j;

import javax.ws.rs.core.MultivaluedHashMap;
        
import com.twitter.hbc.ClientBuilder;
import com.twitter.hbc.core.Constants;
import com.twitter.hbc.core.endpoint.StatusesSampleEndpoint;
import com.twitter.hbc.core.processor.StringDelimitedProcessor;
import com.twitter.hbc.httpclient.BasicClient;
import com.twitter.hbc.httpclient.auth.Authentication;
import com.twitter.hbc.httpclient.auth.OAuth1;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import twitter4j.auth.AccessToken;
import twitter4j.auth.RequestToken;


public class SampleStreamExample {

  public static void run(String consumerKey, String consumerSecret, String token, String secret) throws InterruptedException {
    // Create an appropriately sized blocking queue
    BlockingQueue<String> queue = new LinkedBlockingQueue<String>(10000);

    // Define our endpoint: By default, delimited=length is set (we need this for our processor)
    // and stall warnings are on.
    StatusesSampleEndpoint endpoint = new StatusesSampleEndpoint();
    endpoint.stallWarnings(false);

    Authentication auth = new OAuth1(consumerKey, consumerSecret, token, secret);
    //Authentication auth = new com.twitter.hbc.httpclient.auth.BasicAuth(username, password);
    System.out.println(Constants.STREAM_HOST);
    
    
    Twitter twitter = TwitterFactory.getSingleton();
    Query query = new Query("source:twitter4j yusukey");
    QueryResult result=null;
      try {
          result = twitter.search(query);
      } catch (TwitterException ex) {
          Logger.getLogger(SampleStreamExample.class.getName()).log(Level.SEVERE, null, ex);
      }
    for (Status status : result.getTweets()) {
        System.out.println("@" + status.getUser().getScreenName() + ":" + status.getText());
    }    
    
    // Create a new BasicClient. By default gzip is enabled.    
    BasicClient client = new ClientBuilder()
            .name("UQ")
            .hosts(Constants.STREAM_HOST)
            .endpoint(endpoint)
            .authentication(auth)
            .processor(new StringDelimitedProcessor(queue))
            .build();

    // Establish a connection
    client.connect();

    // Do whatever needs to be done with messages
    for (int msgRead = 0; msgRead < 1000; msgRead++) {
      if (client.isDone()) {
        System.out.println("Client connection closed unexpectedly: " + client.getExitEvent().getMessage());
        break;
      }

      String msg = queue.poll(5, TimeUnit.SECONDS);
      if (msg == null) {
        System.out.println("Did not receive a message in 5 seconds");
      } else {
        System.out.println(msg);
      }
    }

    client.stop();

    // Print some stats
    System.out.printf("The client read %d messages!\n", client.getStatsTracker().getNumMessages());
  }

  public static void main(String[] args) throws IOException {
        
      try {
          final String api_key="5xi95sDq8ZEfoy48j7TKOOLBD";
          final String api_secret="COZ38TtQOnlben9s7ecTCkRYE9wGWvLX7vqGrMa0Jm739bPRUZ";
          final String access_token="306033723-ZDjAly4t3LQSZQZuAZcvmkeh8T9deFHeq0PALmSm";
          final String  access_token_secret="NnyDqn9m4bs08ynxTwJvDbcVtbOZ8lVrsVQcP3ih06dLD";
          // The factory instance is re-useable and thread safe.
          Twitter twitter = TwitterFactory.getSingleton();
          
          
          AccessToken accessToken = loadAccessToken(1);
          
          //twitter.setOAuthConsumerKey("[consumer key]", "[consumer secret]");
          twitter.setOAuthConsumer(api_key, api_secret);
          twitter.setOAuthAccessToken(accessToken);
          /*    Status status;
          try {
          status = twitter.updateStatus("Yea Tao Massage");
          System.out.println("Successfully updated the status to [" + status.getText() + "].");
          } catch (TwitterException ex) {
          Logger.getLogger(SampleStreamExample.class.getName()).log(Level.SEVERE, null, ex);
          }
          */
          Query query = new Query("Brisbane Bus");
          QueryResult result = twitter.search(query);
          for (Status status : result.getTweets()) {
              System.out.println("@" + status.getUser().getScreenName() + ":" + status.getText());
          }
          
          
          System.exit(0);
          
          MultivaluedHashMap<String, String> formParams = new MultivaluedHashMap<>();
          formParams.putSingle("sentence", "?���ߥåɥ����󤫤��������??�ޤ�?����5�֤��Ť��ޤ���");
          formParams.putSingle("output", "xml");
          Client client=null;
          
          /*          client = (Client) new ClientBuilder().build();
          
          String results=client
          .target("http://jlp.yahooapis.jp")
          .path("KeyphraseService/V1/extract")
          .request(MediaType.APPLICATION_XML_TYPE)
          .header("User-Agent", "Yahoo AppID:<appid>")
          .post(Entity.entity(formParams, MediaType.APPLICATION_FORM_URLENCODED_TYPE), String.class);
          System.out.println(results);
          */
          try {
              SampleStreamExample.run(api_key , api_secret, access_token, access_token_secret);
          } catch (InterruptedException ex) {
              Logger.getLogger(SampleStreamExample.class.getName()).log(Level.SEVERE, null, ex);
          }
          
          /*
          //Instantiate a re-usable and thread-safe factory
          TwitterFactory twitterFactory = new TwitterFactory();
          //Instantiate a new Twitter instance
          Twitter twitter = twitterFactory.getInstance();
          //setup OAuth Consumer Credentials
          twitter.setOAuthConsumer(api_key, api_secret);
          //setup OAuth Access Token
          twitter.setOAuthAccessToken(new AccessToken(access_token, access_token_secret));
          //Instantiate and initialize a new twitter status update
          StatusUpdate statusUpdate = new StatusUpdate(
          //your tweet or status message
          "Remeidial massage  on ");
          Status status=null;
          try {
          //attach any media, if you want to
          statusUpdate.setMedia(
          //title of media
          "Yea Tao Massage"
          , new URL("https://acupressure4toowoomba.wordpress.com/").openStream());
          
          //tweet or update status
          status = twitter.updateStatus(statusUpdate);
          
          } catch (MalformedURLException ex) {
          Logger.getLogger(SampleStreamExample.class.getName()).log(Level.SEVERE, null, ex);
          } catch (TwitterException ex) {
          Logger.getLogger(SampleStreamExample.class.getName()).log(Level.SEVERE, null, ex);
          }
          //response from twitter server
          System.out.println("status.toString() = " + status.toString());
          System.out.println("status.getInReplyToScreenName() = " + status.getInReplyToScreenName());
          System.out.println("status.getSource() = " + status.getSource());
          System.out.println("status.getText() = " + status.getText());
          
          System.out.println("status.getURLEntities() = " + Arrays.toString(status.getURLEntities()));
          System.out.println("status.getUserMentionEntities() = " + Arrays.toString(status.getUserMentionEntities()));
          */
          //SampleStreamExample.run(args[0], args[1], args[2], args[3]);
          
          
      } catch (TwitterException ex) {
          Logger.getLogger(SampleStreamExample.class.getName()).log(Level.SEVERE, null, ex);
      }


/*
  //Instantiate a re-usable and thread-safe factory
        TwitterFactory twitterFactory = new TwitterFactory();
        //Instantiate a new Twitter instance
        Twitter twitter = twitterFactory.getInstance();
        //setup OAuth Consumer Credentials
        twitter.setOAuthConsumer(api_key, api_secret);
        //setup OAuth Access Token
        twitter.setOAuthAccessToken(new AccessToken(access_token, access_token_secret));
        //Instantiate and initialize a new twitter status update
        StatusUpdate statusUpdate = new StatusUpdate(
                //your tweet or status message
                "Remeidial massage  on ");
        Status status=null;
      try {
          //attach any media, if you want to
          statusUpdate.setMedia(
                  //title of media
                  "Yea Tao Massage"
                  , new URL("https://acupressure4toowoomba.wordpress.com/").openStream());
          
                  //tweet or update status
        status = twitter.updateStatus(statusUpdate);

      } catch (MalformedURLException ex) {
          Logger.getLogger(SampleStreamExample.class.getName()).log(Level.SEVERE, null, ex);
      } catch (TwitterException ex) {
          Logger.getLogger(SampleStreamExample.class.getName()).log(Level.SEVERE, null, ex);
      }
        //response from twitter server
        System.out.println("status.toString() = " + status.toString());
        System.out.println("status.getInReplyToScreenName() = " + status.getInReplyToScreenName());
        System.out.println("status.getSource() = " + status.getSource());
        System.out.println("status.getText() = " + status.getText());
        
        System.out.println("status.getURLEntities() = " + Arrays.toString(status.getURLEntities()));
        System.out.println("status.getUserMentionEntities() = " + Arrays.toString(status.getUserMentionEntities()));
*/
      //SampleStreamExample.run(args[0], args[1], args[2], args[3]);
        
      
  }

    private static void storeAccessToken(long id, AccessToken accessToken) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static AccessToken loadAccessToken(int parseInt) {
//            String token = // load from a persistent store
  //          String tokenSecret = // load from a persistent store
            final String access_token="306033723-ZDjAly4t3LQSZQZuAZcvmkeh8T9deFHeq0PALmSm";
            final String  access_token_secret="NnyDqn9m4bs08ynxTwJvDbcVtbOZ8lVrsVQcP3ih06dLD";
                    
            return new AccessToken(access_token, access_token_secret);
    }
}
